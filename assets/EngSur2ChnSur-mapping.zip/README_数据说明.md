# Chinese Character–English Spelling Two-way Crosswalk for Chinese Surnames
# 华人姓氏中英文双向对照数据库

**Author / 作者:** Fanghao Chen (Jinan University) — fanghaochen.github.io
**Version / 版本:** 2026-05
**File / 文件:** `EngSur2ChnSur-mapping-long.dta` (Stata, long format)

---

## 1. Description / 数据库描述

This database provides a probabilistic two-way (bidirectional) crosswalk between
Chinese surname characters and their English spellings, covering multiple
romanization/transliteration systems and dialect groups.

本数据库提供华人姓氏汉字与其英文拼写之间的双向概率对照，覆盖多种拼音 / 音译
体系及方言读音。

The mapping is constructed empirically from **foreign nationals recorded in
Chinese business-registration (工商注册) data**. For these individuals the data
observe, for the same person, both the Chinese-character form of the surname and
its English/romanized spelling. By tabulating the observed co-occurrence
frequencies of each character–spelling pair, we obtain the empirical conditional
probabilities reported here. The database is therefore grounded in real,
administratively recorded name pairs rather than in a fixed transliteration rule,
so it naturally captures the heterogeneity of spellings used in practice
(e.g. 陈 → CHEN / CHAN / TAN / CHIN).

本数据库基于**中国工商注册数据中的外籍人士**构建。对于这些个体，数据同时
记录了同一人姓氏的汉字形式与英文 / 罗马化拼写。通过统计每一组「汉字—拼写」
配对的实际共现频次，得到本数据库所报告的经验条件概率。因此，该对照表来源于
真实的行政登记姓名配对，而非固定的音译规则，能够自然反映现实中拼写方式的
多样性（如 陈 → CHEN / CHAN / TAN / CHIN）。

The data are designed to facilitate **cross-language record linkage** in studies
of Chinese migration, diaspora networks, and overseas Chinese business.

该数据旨在为华人移民、侨民网络与海外华商研究中的**跨语言记录匹配**提供
基础工具。

**Coverage / 覆盖范围:** 671 surname–spelling pairs / 配对，
284 unique Chinese surname characters / 个汉字姓氏，
423 unique English spellings / 种英文拼写。

---

## 2. Variables / 变量说明

| Variable | Type | Description (EN) | 中文说明 |
|----------|------|------------------|----------|
| `ch_sur` | string | Chinese surname character | 汉字姓氏 |
| `eng_sur` | string | English / romanized spelling of the surname | 该姓氏的英文（罗马化）拼写 |
| `ch_sur_id` | string | Chinese-surname group identifier (equal to the surname character; used to group all spellings of one character) | 汉字姓氏分组标识（等于该汉字，用于将同一汉字的所有拼写归为一组） |
| `ch_sur_share` | float | **P(ch_sur \| eng_sur)** — conditional probability that a given English spelling corresponds to this Chinese character. Sums to 1 within each `eng_sur`. | 给定某英文拼写时，其对应到该汉字姓氏的条件概率；在同一 `eng_sur` 内求和为 1 |
| `eng_sur_share` | float | **P(eng_sur \| ch_sur)** — conditional probability that a given Chinese character is spelled this English way. Sums to 1 within each `ch_sur`. | 给定某汉字姓氏时，其采用该英文拼写的条件概率；在同一 `ch_sur` 内求和为 1 |

The two share variables make the crosswalk **two-way**:

- **English → Chinese:** filter on `eng_sur`, then use `ch_sur_share` to weight the
  candidate Chinese characters.
- **Chinese → English:** filter on `ch_sur`, then use `eng_sur_share` to weight the
  candidate English spellings.

两个 share 变量使该对照表实现**双向**使用：

- **英文 → 中文：** 按 `eng_sur` 筛选，用 `ch_sur_share` 对候选汉字加权。
- **中文 → 英文：** 按 `ch_sur` 筛选，用 `eng_sur_share` 对候选拼写加权。

The data are in **long format**: each row is one (`ch_sur`, `eng_sur`) pair, so a
single Chinese character may appear in multiple rows (one per spelling) and a
single English spelling may appear in multiple rows (one per character).

数据为**长格式**：每行对应一组（`ch_sur`, `eng_sur`）配对，因此同一汉字可出现在
多行（每种拼写一行），同一英文拼写也可出现在多行（每个汉字一行）。

---

## 3. Citation / 引用

If you use this data in your research, please cite:

使用本数据请引用：

> Fanghao Chen, Ruichi Xiong, Xiaobo Zhang. *Familiar Strangers: The Role of
> Diaspora Networks in Foreign Investment and Long-run Development.*
> *Journal of International Economics*, forthcoming.
> SSRN: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4004159

---

## 4. Terms of use / 使用条款

Freely available for academic use. Please cite the paper above if you use any of
the data in your research.

可免费用于学术研究。使用时请引用上述论文。
